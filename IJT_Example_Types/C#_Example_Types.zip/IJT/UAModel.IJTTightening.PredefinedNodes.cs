/* ========================================================================
 * Copyright (c) 2005-2024 The OPC Foundation, Inc. All rights reserved.
 *
 * OPC Foundation MIT License 1.00
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * The complete license agreement can be found here:
 * http://opcfoundation.org/License/MIT/1.00/
 * ======================================================================*/

using System;
using System.Text;
using System.IO;
using Opc.Ua;
using UAModel.DI;
using UAModel.AMB;
using UAModel.IA;
using UAModel.Machinery;
using UAModel.MachineryResult;
using UAModel.IJTBase;

#pragma warning disable CS1591 // Missing XML comment for publicly visible type or member
#pragma warning disable CA1515 // Consider making public types internal
#pragma warning disable CA1707 // Identifiers should not contain underscores
#pragma warning disable CA1028 // Enum Storage should be Int32

namespace UAModel.IJTTightening
{
    #region _ClassName_ Declarations
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Opc.Ua.ModelCompiler", "1.0.0.0")]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverageAttribute()]
    public static partial class PredefinedNodes
    {
        #region PredefinedNodes Declarations
        // <summary/>
        public static NodeStateCollection Load(ISystemContext context)
        {
            byte[] initializationBuffer = Convert.FromBase64String(
               "BwAAACsAAABodHRwOi8vb3BjZm91bmRhdGlvbi5vcmcvVUEvSUpUL1RpZ2h0ZW5pbmcvJQAAAGh0dHA6" +
               "Ly9vcGNmb3VuZGF0aW9uLm9yZy9VQS9JSlQvQmFzZS8mAAAAaHR0cDovL29wY2ZvdW5kYXRpb24ub3Jn" +
               "L1VBL01hY2hpbmVyeS8fAAAAaHR0cDovL29wY2ZvdW5kYXRpb24ub3JnL1VBL0lBLx8AAABodHRwOi8v" +
               "b3BjZm91bmRhdGlvbi5vcmcvVUEvREkvIAAAAGh0dHA6Ly9vcGNmb3VuZGF0aW9uLm9yZy9VQS9BTUIv" +
               "LQAAAGh0dHA6Ly9vcGNmb3VuZGF0aW9uLm9yZy9VQS9NYWNoaW5lcnkvUmVzdWx0L/////8BAAAAJGgA" +
               "EAgAAAABAB0AAABJVGlnaHRlbmluZ1Rvb2xQYXJhbWV0ZXJzVHlwZQEB6wMDAAAAALIAAABUaGlzIGlu" +
               "dGVyZmFjZSBpcyBpbmhlcml0ZWQgZnJvbSAwOkJhc2VJbnRlcmZhY2VUeXBlIHRvIGFkZCBhZGRpdGlv" +
               "bmFsIHBhcmFtZXRlcnMgb2YgYSB0b29sIGluIGEgdGlnaHRlbmluZyBzeXN0ZW0uIEl0IHNoYWxsIGJl" +
               "IGFkZGVkIHRvIDI6UGFyYW1ldGVycyBvYmplY3Qgb2YgdGhlIHRvb2wgaW5zdGFuY2UuAQDCRAH/////" +
               "CAAAADVgqQsCAAAAAQAKAAAARGVzaWduVHlwZQEBdRcDAAAAADoAAABEZXNpZ25UeXBlIHByb3ZpZGVz" +
               "IGluZm9ybWF0aW9uIG9uIHRoZSBkZXNpZ24gb2YgdGhlIFRvb2wuAC8BAEgJAE51FwAAAwAAA/////8B" +
               "Af////8BAAAAF2CpCwIAAAAAAAsAAABFbnVtU3RyaW5ncwEBdhcALgBEAE52FwAAlQYAAAACBQAAAE9U" +
               "SEVSAgYAAABQSVNUT0wCBQAAAEFOR0xFAggAAABTVFJBSUdIVAIGAAAAT0ZGU0VUAg4AAABSRVZFUlNF" +
               "X09GRlNFVAAVAQAAAAEAAAAAAAAAAQH/////AAAAADVgqQsCAAAAAQALAAAARHJpdmVNZXRob2QBAX4X" +
               "AwAAAABOAAAARHJpdmVNZXRob2QgcHJvdmlkZXMgaW5mb3JtYXRpb24gb24gdGhlIGRyaXZlIG1ldGhv" +
               "ZCBvZiB0aGUgbW90b3Igb2YgdGhlIFRvb2wuAC8BAEgJAE5+FwAAAwAAA/////8BAf////8BAAAAF2Cp" +
               "CwIAAAAAAAsAAABFbnVtU3RyaW5ncwEBfxcALgBEAE5/FwAAlQgAAAACBQAAAE9USEVSAgoAAABDT05U" +
               "SU5VT1VTAgUAAABQVUxTRQIKAAAAUkFUQ0hFVElORwIKAAAAVEVOU0lPTklORwIGAAAATUFOVUFMAgcA" +
               "AABJTkVSVElBAgYAAABIWUJSSUQAFQEAAAABAAAAAAAAAAEB/////wAAAAA1YKkLAgAAAAEACQAAAERy" +
               "aXZlVHlwZQEBgBcDAAAAAD0AAABEcml2ZVR5cGUgcHJvdmlkZXMgaW5mb3JtYXRpb24gb24gdGhlIGRy" +
               "aXZlIHR5cGUgb2YgdGhlIFRvb2wuAC8BAEgJAE6AFwAAAwAAA/////8BAf////8BAAAAF2CpCwIAAAAA" +
               "AAsAAABFbnVtU3RyaW5ncwEBgRcALgBEAE6BFwAAlQUAAAACBQAAAE9USEVSAggAAABFTEVDVFJJQwIJ" +
               "AAAASFlEUkFVTElDAgkAAABQTkVVTUFUSUMCBgAAAE1BTlVBTAAVAQAAAAEAAAAAAAAAAQH/////AAAA" +
               "ADVgqQsCAAAAAQAIAAAATWF4U3BlZWQBAYYXAwAAAAA8AAAATWF4U3BlZWQgaXMgdGhlIG1heGltdW0g" +
               "cm90YXRpb24gc3BlZWQgb2YgdGhlIGRyaXZpbmcgc2hhZnQuAC8BAtsHAFCGFwAACwAAAAAAAAAAAAv/" +
               "////AQH/////AgAAADVgqQsCAAAAAgAQAAAARW5naW5lZXJpbmdVbml0cwEBlBcDAAAAAD4AAAAwOkVu" +
               "Z2luZWVyaW5nVW5pdHMgZGVmaW5lcyB0aGUgZW5naW5lZXJpbmcgdW5pdCBvZiB0aGUgdmFsdWVzLgAu" +
               "AEQAUJQXAAAWAQB5AwEKAAAAAAAAAP////8AAAEAdwP/////AQH/////AAAAADVgqQsCAAAAAgAQAAAA" +
               "UGh5c2ljYWxRdWFudGl0eQEBihcDAAAAAGIAAABQaHlzaWNhbFF1YW50aXR5IGlzIHRvIGRldGVybWlu" +
               "ZSB0aGUgdHlwZSBvZiB0aGUgcGh5c2ljYWwgcXVhbnRpdHkgYXNzb2NpYXRlZCB0byBhIGdpdmVuIHZh" +
               "bHVlKHMpLgAvAQBICQBQihcAAAMAAAP/////AQH/////AQAAABdgqQsCAAAAAAALAAAARW51bVN0cmlu" +
               "Z3MBAYsXAC4ARABOixcAAJUdAAAAAgUAAABPVEhFUgIEAAAAVElNRQIGAAAAVE9SUVVFAgUAAABBTkdM" +
               "RQIHAAAASU1QVUxTRQIIAAAARElTVEFOQ0UCBAAAAEFSRUECBgAAAFZPTFVNRQIFAAAARk9SQ0UCCAAA" +
               "AFBSRVNTVVJFAgcAAABWT0xUQUdFAgcAAABDVVJSRU5UAgoAAABSRVNJU1RBTkNFAgUAAABQT1dFUgIG" +
               "AAAARU5FUkdZAgQAAABNQVNTAgsAAABURU1QRVJBVFVSRQIJAAAARlJFUVVFTkNZAgQAAABKT0xUAgkA" +
               "AABWSUJSQVRJT04CBgAAAE5VTUJFUgIMAAAATElORUFSX1NQRUVEAg0AAABBTkdVTEFSX1NQRUVEAhMA" +
               "AABMSU5FQVJfQUNDRUxFUkFUSU9OAhQAAABBTkdVTEFSX0FDQ0VMRVJBVElPTgIMAAAAVE9SUVVFX1NQ" +
               "RUVEAhMAAABUT1JRVUVfQUNDRUxFUkFUSU9OAhkAAABUT1JRVUVfUEVSX0FOR0xFX0dSQURJRU5UAhoA" +
               "AABUT1JRVUVfUEVSX0FOR0xFX0dSQURJRU5UMgAVAQAAAAEAAAAAAAAAAQH/////AAAAADVgqQsCAAAA" +
               "AQAJAAAATWF4VG9ycXVlAQGEFwMAAAAAjQAAAE1heFRvcnF1ZSBpcyB0aGUgbWF4aW11bSBhbGxvd2Vk" +
               "IHRvcnF1ZSBmb3Igd2hpY2ggdGhlIHRvb2wgbWF5IGJlIHVzZWQgZm9yIHRpZ2h0ZW5pbmcgcHJvY2Vz" +
               "c2VzLiBGb3IgQ2xpY2sgV3JlbmNoZXMsIGl0IG1heSBub3QgYmUgYXZhaWxhYmxlLgAvAQLbBwBQhBcA" +
               "AAsAAAAAAAAAAAAL/////wEB/////wIAAAA1YKkLAgAAAAIAEAAAAEVuZ2luZWVyaW5nVW5pdHMBAYwX" +
               "AwAAAAA+AAAAMDpFbmdpbmVlcmluZ1VuaXRzIGRlZmluZXMgdGhlIGVuZ2luZWVyaW5nIHVuaXQgb2Yg" +
               "dGhlIHZhbHVlcy4ALgBEAFCMFwAAFgEAeQMBCgAAAAAAAAD/////AAABAHcD/////wEB/////wAAAAA1" +
               "YKkLAgAAAAIAEAAAAFBoeXNpY2FsUXVhbnRpdHkBAY0XAwAAAABiAAAAUGh5c2ljYWxRdWFudGl0eSBp" +
               "cyB0byBkZXRlcm1pbmUgdGhlIHR5cGUgb2YgdGhlIHBoeXNpY2FsIHF1YW50aXR5IGFzc29jaWF0ZWQg" +
               "dG8gYSBnaXZlbiB2YWx1ZShzKS4ALwEASAkAUI0XAAADAAAD/////wEB/////wEAAAAXYKkLAgAAAAAA" +
               "CwAAAEVudW1TdHJpbmdzAQGQFwAuAEQATpAXAACVHQAAAAIFAAAAT1RIRVICBAAAAFRJTUUCBgAAAFRP" +
               "UlFVRQIFAAAAQU5HTEUCBwAAAElNUFVMU0UCCAAAAERJU1RBTkNFAgQAAABBUkVBAgYAAABWT0xVTUUC" +
               "BQAAAEZPUkNFAggAAABQUkVTU1VSRQIHAAAAVk9MVEFHRQIHAAAAQ1VSUkVOVAIKAAAAUkVTSVNUQU5D" +
               "RQIFAAAAUE9XRVICBgAAAEVORVJHWQIEAAAATUFTUwILAAAAVEVNUEVSQVRVUkUCCQAAAEZSRVFVRU5D" +
               "WQIEAAAASk9MVAIJAAAAVklCUkFUSU9OAgYAAABOVU1CRVICDAAAAExJTkVBUl9TUEVFRAINAAAAQU5H" +
               "VUxBUl9TUEVFRAITAAAATElORUFSX0FDQ0VMRVJBVElPTgIUAAAAQU5HVUxBUl9BQ0NFTEVSQVRJT04C" +
               "DAAAAFRPUlFVRV9TUEVFRAITAAAAVE9SUVVFX0FDQ0VMRVJBVElPTgIZAAAAVE9SUVVFX1BFUl9BTkdM" +
               "RV9HUkFESUVOVAIaAAAAVE9SUVVFX1BFUl9BTkdMRV9HUkFESUVOVDIAFQEAAAABAAAAAAAAAAEB////" +
               "/wAAAAA1YKkLAgAAAAEACQAAAE1pblRvcnF1ZQEBhRcDAAAAAGAAAABNaW5Ub3JxdWUgaXMgdGhlIG1p" +
               "bmltdW0gYWxsb3dlZCB0b3JxdWUgZm9yIHdoaWNoIHRoZSB0b29sIG1heSBiZSB1c2VkIGZvciB0aWdo" +
               "dGVuaW5nIHByb2Nlc3Nlcy4ALwEC2wcAUIUXAAALAAAAAAAAAAAAC/////8BAf////8CAAAANWCpCwIA" +
               "AAACABAAAABFbmdpbmVlcmluZ1VuaXRzAQGIFwMAAAAAPgAAADA6RW5naW5lZXJpbmdVbml0cyBkZWZp" +
               "bmVzIHRoZSBlbmdpbmVlcmluZyB1bml0IG9mIHRoZSB2YWx1ZXMuAC4ARABQiBcAABYBAHkDAQoAAAAA" +
               "AAAA/////wAAAQB3A/////8BAf////8AAAAANWCpCwIAAAACABAAAABQaHlzaWNhbFF1YW50aXR5AQGJ" +
               "FwMAAAAAYgAAAFBoeXNpY2FsUXVhbnRpdHkgaXMgdG8gZGV0ZXJtaW5lIHRoZSB0eXBlIG9mIHRoZSBw" +
               "aHlzaWNhbCBxdWFudGl0eSBhc3NvY2lhdGVkIHRvIGEgZ2l2ZW4gdmFsdWUocykuAC8BAEgJAFCJFwAA" +
               "AwAAA/////8BAf////8BAAAAF2CpCwIAAAAAAAsAAABFbnVtU3RyaW5ncwEBkRcALgBEAE6RFwAAlR0A" +
               "AAACBQAAAE9USEVSAgQAAABUSU1FAgYAAABUT1JRVUUCBQAAAEFOR0xFAgcAAABJTVBVTFNFAggAAABE" +
               "SVNUQU5DRQIEAAAAQVJFQQIGAAAAVk9MVU1FAgUAAABGT1JDRQIIAAAAUFJFU1NVUkUCBwAAAFZPTFRB" +
               "R0UCBwAAAENVUlJFTlQCCgAAAFJFU0lTVEFOQ0UCBQAAAFBPV0VSAgYAAABFTkVSR1kCBAAAAE1BU1MC" +
               "CwAAAFRFTVBFUkFUVVJFAgkAAABGUkVRVUVOQ1kCBAAAAEpPTFQCCQAAAFZJQlJBVElPTgIGAAAATlVN" +
               "QkVSAgwAAABMSU5FQVJfU1BFRUQCDQAAAEFOR1VMQVJfU1BFRUQCEwAAAExJTkVBUl9BQ0NFTEVSQVRJ" +
               "T04CFAAAAEFOR1VMQVJfQUNDRUxFUkFUSU9OAgwAAABUT1JRVUVfU1BFRUQCEwAAAFRPUlFVRV9BQ0NF" +
               "TEVSQVRJT04CGQAAAFRPUlFVRV9QRVJfQU5HTEVfR1JBRElFTlQCGgAAAFRPUlFVRV9QRVJfQU5HTEVf" +
               "R1JBRElFTlQyABUBAAAAAQAAAAAAAAABAf////8AAAAANWCpCwIAAAABAAkAAABNb3RvclR5cGUBAYcX" +
               "AwAAAAArAAAATW90b3JUeXBlIGlzIHRoZSB0eXBlIG9mIG1vdG9yIGluIHRoZSB0b29sLgAvAD8AUIcX" +
               "AAAMAAAAAAAM/////wEB/////wAAAAA1YKkLAgAAAAEADQAAAFNodXRPZmZNZXRob2QBAYIXAwAAAABF" +
               "AAAAU2h1dE9mZk1ldGhvZCBwcm92aWRlcyBpbmZvcm1hdGlvbiBvbiB0aGUgc2h1dG9mZiBtZXRob2Qg" +
               "b2YgdGhlIHRvb2wuAC8BAEgJAFCCFwAAAwAAA/////8BAf////8BAAAAF2CpCwIAAAAAAAsAAABFbnVt" +
               "U3RyaW5ncwEBgxcALgBEAE6DFwAAlQQAAAACBQAAAE9USEVSAgoAAABNRUNIQU5JQ0FMAgcAAABDVVJS" +
               "RU5UAgoAAABUUkFOU0RVQ0VSABUBAAAAAQAAAAAAAAABAf////8AAAAA"
            );
            using (MemoryStream stream = new MemoryStream(initializationBuffer))
            {
                NodeStateCollection predefinedNodes = new NodeStateCollection();
                predefinedNodes.LoadFromBinary(context, stream, true);
                return predefinedNodes;
            }
        }
        #endregion
    }
    #endregion
}