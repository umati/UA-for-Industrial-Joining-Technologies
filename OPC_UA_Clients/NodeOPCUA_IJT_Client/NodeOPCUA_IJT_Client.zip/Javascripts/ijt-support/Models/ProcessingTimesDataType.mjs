import IJTBaseModel from './IJTBaseModel.mjs'

// The purpose of this class is to model the Processing times data structure
export default class ProcessingTimesDataType extends IJTBaseModel {
}
